module.exports = {
  setupFilesAfterEnv: ["./jest.setup.ts"],
}
