chrome.devtools.panels.create(
  "GraphQL Network",
  "/icon.png",
  "/index.html",
  null
)
